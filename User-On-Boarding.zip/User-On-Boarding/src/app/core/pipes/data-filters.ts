// import {Pipe, PipeTransform} from '@angular/core';
// import { UserDataModel } from '../model/user-data.model';
// type NewType = UserDataModel;

// @Pipe ({
//    name : 'filters'
// })
// export class DataFilters implements PipeTransform {
//    transform(val :  Array<NewType>) : Array<NewType> {
//        console.log(val);
//      return val;
//    }
// }